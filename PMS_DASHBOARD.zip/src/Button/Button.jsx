
import './button.css'
export default function Button({ title }) {

    return (
        <button className='btn1'>{title}</button>
    )
}
