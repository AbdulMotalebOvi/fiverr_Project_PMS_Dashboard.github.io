import './button.css'

export default function ButtonWhite({ title }) {
    return (
        <button className='btn2'>{title}</button>
    )
}
