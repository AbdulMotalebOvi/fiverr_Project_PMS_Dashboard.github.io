import React from "react";
import Form from "./Form";

export default function SignIn() {

    return (
        <>
            <div className="mt-[10%]">
                <Form />
            </div>
        </>
    )
}