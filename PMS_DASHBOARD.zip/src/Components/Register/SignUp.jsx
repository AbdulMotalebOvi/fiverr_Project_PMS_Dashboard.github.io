
import Form from "./Form";

export default function SignUp() {

    return (
        <div className="mt-[10%]">
            <Form />
        </div>

    )
}